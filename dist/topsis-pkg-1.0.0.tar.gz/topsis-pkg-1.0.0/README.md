# topsis-pkg
Python Package with implementation of TOPSIS

A cmd line solution is present with this module:

Usages: python topsis.py InputDataFile Weights Impacts

Example: python topsis.py myData.csv “1,2,1,1” “+,+,-+”
